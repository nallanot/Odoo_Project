# -*- coding: utf-8 -*-

from datetime import date, datetime, time, timedelta

from odoo import api, fields, models
from odoo.exceptions import UserError


class ProjectTask(models.Model):
    _inherit = "project.task"

    gantt_start_date = fields.Date(string="Début Gantt")
    gantt_end_date = fields.Date(string="Fin Gantt")
    gantt_progress = fields.Integer(
        string="Avancement Gantt (%)",
        default=0,
        help="Progression affichée dans la barre Gantt. Valeur entre 0 et 100.",
    )

    # Champs du nouvel onglet « Gantt Detail », inspirés de la capture fournie.
    gantt_unscheduled = fields.Boolean(string="Unscheduled")
    gantt_task_type = fields.Selection(
        selection=[("task", "Task"), ("milestone", "Milestone")],
        string="Task Type",
        default="task",
        required=True,
    )
    gantt_enable_duration = fields.Boolean(string="Enable Task Duration", default=True)
    gantt_start_datetime = fields.Datetime(string="Start Date")
    gantt_end_datetime = fields.Datetime(string="End Date")
    gantt_duration_hours = fields.Float(string="Duration Hours", compute="_compute_gantt_duration", store=False)
    gantt_duration_display = fields.Char(string="Duration", compute="_compute_gantt_duration", store=False)
    gantt_average_hour_per_day = fields.Float(string="Average Hour per Day", default=8.0)
    gantt_schedule_mode = fields.Selection(
        selection=[("auto", "Auto"), ("manual", "Manual")],
        string="Schedule Mode",
        default="manual",
        required=True,
    )
    gantt_constraint_type = fields.Selection(
        selection=[
            ("as_soon_as_possible", "As Soon As Possible"),
            ("as_late_as_possible", "As Late As Possible"),
            ("start_no_earlier_than", "Start No Earlier Than"),
            ("start_no_later_than", "Start No Later Than"),
            ("finish_no_earlier_than", "Finish No Earlier Than"),
            ("finish_no_later_than", "Finish No Later Than"),
            ("must_start_on", "Must Start On"),
            ("must_finish_on", "Must Finish On"),
        ],
        string="Constraint Type",
        default="start_no_earlier_than",
    )
    gantt_constraint_datetime = fields.Datetime(string="Constraint Date")
    gantt_predecessor_ids = fields.Many2many(
        comodel_name="project.task",
        relation="project_task_gantt_predecessor_rel",
        column1="task_id",
        column2="predecessor_id",
        string="Predecessors",
        domain="[(\'id\', \'!=\', id)]",
    )
    gantt_successor_ids = fields.Many2many(
        comodel_name="project.task",
        relation="project_task_gantt_successor_rel",
        column1="task_id",
        column2="successor_id",
        string="Successors",
        domain="[(\'id\', \'!=\', id)]",
    )

    @api.depends("gantt_start_datetime", "gantt_end_datetime", "gantt_task_type")
    def _compute_gantt_duration(self):
        for task in self:
            if task.gantt_task_type == "milestone":
                task.gantt_duration_hours = 0.0
                task.gantt_duration_display = "Milestone"
                continue

            start_dt = task.gantt_start_datetime
            end_dt = task.gantt_end_datetime
            if not start_dt or not end_dt:
                start_date, end_date = task._gantt_effective_dates()
                start_dt = datetime.combine(start_date, time.min)
                end_dt = datetime.combine(end_date, time.max)

            if end_dt < start_dt:
                end_dt = start_dt
            delta = end_dt - start_dt
            total_seconds = int(delta.total_seconds())
            total_hours = max(total_seconds / 3600.0, 0.0)
            days = total_seconds // 86400
            seconds = total_seconds % 86400
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            task.gantt_duration_hours = total_hours
            task.gantt_duration_display = "%s jours, %02d:%02d:00" % (days, hours, minutes)

    @api.onchange("gantt_task_type", "gantt_start_datetime", "gantt_end_datetime")
    def _onchange_gantt_datetime(self):
        for task in self:
            if task.gantt_task_type == "milestone" and task.gantt_start_datetime:
                task.gantt_end_datetime = task.gantt_start_datetime
            if task.gantt_start_datetime and task.gantt_end_datetime and task.gantt_end_datetime < task.gantt_start_datetime:
                task.gantt_end_datetime = task.gantt_start_datetime
            if task.gantt_start_datetime:
                task.gantt_start_date = fields.Date.to_date(task.gantt_start_datetime)
            if task.gantt_end_datetime:
                task.gantt_end_date = fields.Date.to_date(task.gantt_end_datetime)

    @api.constrains("gantt_progress")
    def _check_gantt_progress(self):
        for task in self:
            if task.gantt_progress < 0 or task.gantt_progress > 100:
                raise UserError("L'avancement Gantt doit être entre 0 et 100.")

    @api.constrains("gantt_start_datetime", "gantt_end_datetime")
    def _check_gantt_dates(self):
        for task in self:
            if task.gantt_start_datetime and task.gantt_end_datetime and task.gantt_end_datetime < task.gantt_start_datetime:
                raise UserError("La date de fin Gantt ne peut pas être avant la date de début.")

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            self._normalize_gantt_vals(vals)
        return super().create(vals_list)

    def write(self, vals):
        vals = dict(vals)
        self._normalize_gantt_vals(vals)
        return super().write(vals)

    @api.model
    def _normalize_gantt_vals(self, vals):
        start_dt = vals.get("gantt_start_datetime")
        end_dt = vals.get("gantt_end_datetime")
        task_type = vals.get("gantt_task_type")

        if task_type == "milestone" and start_dt and not end_dt:
            vals["gantt_end_datetime"] = start_dt
            end_dt = start_dt

        if start_dt:
            vals["gantt_start_date"] = fields.Date.to_string(fields.Datetime.to_datetime(start_dt).date())
        if end_dt:
            vals["gantt_end_date"] = fields.Date.to_string(fields.Datetime.to_datetime(end_dt).date())
        return vals

    def _gantt_to_date(self, value):
        """Convert any Odoo date/datetime/string value to a pure date.

        This keeps v19.0.1.1.x stable when Odoo mixes Date and Datetime
        values, for example between Gantt fields, deadlines and native planned
        dates. Without this normalization, Python can raise:
        TypeError: can't compare datetime.datetime to datetime.date
        """
        if not value:
            return False
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        converted = fields.Date.to_date(value)
        if isinstance(converted, datetime):
            return converted.date()
        return converted

    def _gantt_effective_dates(self):
        """Return safe start/end dates for display.

        The OWL client action receives ISO dates only (YYYY-MM-DD). This avoids
        browser-side parsing issues such as DD/MM/YYYY being interpreted in the
        wrong column. All internal values are normalized to `datetime.date`.
        """
        self.ensure_one()
        start = self._gantt_to_date(self.gantt_start_datetime) or self._gantt_to_date(self.gantt_start_date)
        end = self._gantt_to_date(self.gantt_end_datetime) or self._gantt_to_date(self.gantt_end_date)

        if not start:
            # Optional native Odoo fields vary by edition/modules, so check them
            # dynamically before using them.
            if "planned_date_begin" in self._fields and self.planned_date_begin:
                start = self._gantt_to_date(self.planned_date_begin)
            elif self.create_date:
                start = self._gantt_to_date(self.create_date)
            elif self.date_deadline:
                start = self._gantt_to_date(self.date_deadline)
            else:
                start = self._gantt_to_date(fields.Date.context_today(self))

        if not end:
            if "planned_date_end" in self._fields and self.planned_date_end:
                end = self._gantt_to_date(self.planned_date_end)
            else:
                end = self._gantt_to_date(self.date_deadline) or start

        # Sécurité supplémentaire : certains champs Odoo peuvent revenir en
        # datetime malgré les conversions précédentes. On normalise donc une
        # dernière fois juste avant toute comparaison Python.
        start = self._gantt_to_date(start)
        end = self._gantt_to_date(end) or start

        if self.gantt_task_type == "milestone":
            end = start

        if end < start:
            end = start

        return start, end

    def _gantt_level(self):
        self.ensure_one()
        if "parent_id" not in self._fields:
            return 0
        level = 0
        parent = self.parent_id
        while parent and level < 8:
            level += 1
            parent = parent.parent_id if "parent_id" in parent._fields else False
        return level

    def _gantt_has_children(self):
        self.ensure_one()
        return bool("child_ids" in self._fields and self.child_ids)

    def _gantt_duration_label(self, start, end):
        self.ensure_one()
        if self.gantt_task_type == "milestone":
            return "Milestone"
        if self.gantt_enable_duration and self.gantt_duration_display:
            return self.gantt_duration_display
        days = max((end - start).days + 1, 1)
        if days == 1:
            return "1 jour"
        return "%s jours" % days

    def _gantt_start_display(self, task_start):
        self.ensure_one()
        if self.gantt_start_datetime:
            return fields.Datetime.to_string(self.gantt_start_datetime)
        return "%s 00:00:00" % fields.Date.to_string(task_start)

    @api.model
    def project_gantt_get_projects(self):
        return self.env["project.project"].search_read([], ["name"], order="name asc")

    @api.model
    def project_gantt_get_data(self, project_id=False, start=False, end=False, sort="default", **kwargs):
        """Return tasks for the custom Gantt view.

        start/end are ISO strings and define the visible timeline. Tasks are
        returned when their effective period intersects the timeline. The result
        also includes UI metadata used by the toolbar added in v19.0.1.1.0.
        """
        start_date = fields.Date.to_date(start) if start else fields.Date.context_today(self) - timedelta(days=7)
        end_date = fields.Date.to_date(end) if end else start_date + timedelta(days=30)

        domain = []
        if project_id:
            domain.append(("project_id", "=", int(project_id)))

        order = "project_id, sequence, id"
        if sort == "name":
            order = "name asc, id asc"
        elif sort == "start":
            order = "gantt_start_date asc, date_deadline asc, id asc"
        elif sort == "project":
            order = "project_id asc, sequence asc, id asc"

        tasks = self.search(domain, order=order, limit=1500)

        raw_rows = []
        max_duration = 1
        for task in tasks:
            task_start, task_end = task._gantt_effective_dates()
            if task_end < start_date or task_start > end_date:
                continue
            duration_days = max((task_end - task_start).days + 1, 1)
            max_duration = max(max_duration, duration_days)

            user_names = ""
            if "user_ids" in task._fields:
                user_names = ", ".join(task.user_ids.mapped("name"))

            parent_id = False
            if "parent_id" in task._fields and task.parent_id:
                parent_id = task.parent_id.id

            raw_rows.append({
                "id": task.id,
                "name": task.name or "Sans titre",
                "project_id": task.project_id.id if task.project_id else False,
                "project_name": task.project_id.name if task.project_id else "Sans projet",
                "user_names": user_names,
                "stage_name": task.stage_id.name if task.stage_id else "",
                "start": fields.Date.to_string(task_start),
                "end": fields.Date.to_string(task_end),
                "deadline": fields.Date.to_string(task.date_deadline) if task.date_deadline else "",
                "progress": max(0, min(task.gantt_progress or 0, 100)),
                "duration_days": duration_days,
                "duration_label": task._gantt_duration_label(task_start, task_end),
                "start_display": task._gantt_start_display(task_start),
                "parent_id": parent_id,
                "level": task._gantt_level(),
                "has_children": task._gantt_has_children(),
                "task_type": task.gantt_task_type or "task",
                "is_milestone": task.gantt_task_type == "milestone",
                "unscheduled": bool(task.gantt_unscheduled),
                "schedule_mode": task.gantt_schedule_mode or "manual",
                "constraint_type": task.gantt_constraint_type or "",
                "constraint_date": fields.Datetime.to_string(task.gantt_constraint_datetime) if task.gantt_constraint_datetime else "",
            })

        if sort == "duration":
            raw_rows.sort(key=lambda row: (-row["duration_days"], row["name"]))

        # Dependency data is not available in Odoo Community by default. The
        # critical-path toggle therefore highlights the longest visible tasks,
        # which is useful without pretending to be a full CPM engine.
        critical_threshold = max(2, int(max_duration * 0.65))
        for row in raw_rows:
            row["is_critical"] = bool(row["duration_days"] >= critical_threshold)

        return raw_rows

    @api.model
    def project_gantt_get_bounds(self, project_id=False):
        domain = []
        if project_id:
            domain.append(("project_id", "=", int(project_id)))
        tasks = self.search(domain, order="project_id, sequence, id", limit=1500)
        if not tasks:
            today = fields.Date.context_today(self)
            return {
                "start": fields.Date.to_string(today - timedelta(days=7)),
                "end": fields.Date.to_string(today + timedelta(days=30)),
            }
        min_start = None
        max_end = None
        for task in tasks:
            task_start, task_end = task._gantt_effective_dates()
            min_start = task_start if min_start is None else min(min_start, task_start)
            max_end = task_end if max_end is None else max(max_end, task_end)
        return {
            "start": fields.Date.to_string(min_start - timedelta(days=2)),
            "end": fields.Date.to_string(max_end + timedelta(days=2)),
        }

    @api.model
    def project_gantt_update_dates(self, task_id, start, end):
        task = self.browse(int(task_id)).exists()
        if not task:
            raise UserError("Tâche introuvable.")
        start_date = fields.Date.to_date(start)
        end_date = fields.Date.to_date(end)
        if end_date < start_date:
            raise UserError("La date de fin ne peut pas être avant la date de début.")

        start_dt = datetime.combine(start_date, time.min)
        end_dt = datetime.combine(end_date, time.max)
        if task.gantt_task_type == "milestone":
            end_date = start_date
            end_dt = start_dt

        vals = {
            "gantt_start_date": fields.Date.to_string(start_date),
            "gantt_end_date": fields.Date.to_string(end_date),
            "gantt_start_datetime": fields.Datetime.to_string(start_dt),
            "gantt_end_datetime": fields.Datetime.to_string(end_dt),
            "date_deadline": fields.Date.to_string(end_date),
        }
        if "planned_date_begin" in task._fields:
            vals["planned_date_begin"] = fields.Datetime.to_string(fields.Datetime.to_datetime(start_date))
        if "planned_date_end" in task._fields:
            vals["planned_date_end"] = fields.Datetime.to_string(fields.Datetime.to_datetime(end_date))
        task.write(vals)
        return True

    @api.model
    def project_gantt_resequence(self, ordered_ids):
        """Update the manual order of tasks after drag-and-drop in the Gantt.

        The client sends the visible ids for one project in the desired order.
        We only update the standard `sequence` field, so the change remains
        compatible with Odoo Community and the native project task ordering.
        """
        ids = [int(task_id) for task_id in (ordered_ids or []) if task_id]
        if not ids:
            return True
        tasks = self.browse(ids).exists()
        task_by_id = {task.id: task for task in tasks}
        for index, task_id in enumerate(ids):
            task = task_by_id.get(task_id)
            if task and "sequence" in task._fields:
                task.write({"sequence": (index + 1) * 10})
        return True

    @api.model
    def project_gantt_update_progress(self, task_id, progress):
        task = self.browse(int(task_id)).exists()
        if not task:
            raise UserError("Tâche introuvable.")
        progress = int(progress or 0)
        progress = max(0, min(progress, 100))
        task.write({"gantt_progress": progress})
        return True
