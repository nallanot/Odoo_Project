# -*- coding: utf-8 -*-
{
    "name": "Project Gantt CE",
    "summary": "Vue Gantt projet avancée pour Odoo Community avec barre type enterprise et barre de création Odoo conservée",
    "version": "19.0.1.1.9",
    "category": "Project",
    "author": "Custom",
    "license": "LGPL-3",
    "depends": ["project", "web"],
    "data": [
        "views/project_task_views.xml",
        "views/project_gantt_menu.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "project_gantt_ce/static/src/js/project_gantt_ce.js",
            "project_gantt_ce/static/src/xml/project_gantt_ce.xml",
            "project_gantt_ce/static/src/scss/project_gantt_ce.scss",
        ],
    },
    "installable": True,
    "application": False,
}
