/** @odoo-module **/

import { Component, onWillStart, useRef, useState } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

class ProjectGanttCE extends Component {
    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.notification = useService("notification");

        this.chartScrollRef = useRef("chartScroll");
        this.leftBodyRef = useRef("leftBody");

        this.rowHeight = 36;
        this.headerHeight = 52;

        const start = this.addDays(this.todayLocal(), -2);
        this.state = useState({
            loading: true,
            projects: [],
            tasks: [],
            projectId: "",
            start: this.formatDate(start),
            scale: "day",
            sort: "default",
            search: "",
            showGraphOverlay: false,
            showDuration: true,
            showGrid: true,
            showResourcePanel: false,
            showCriticalPath: false,
            showDeadline: true,
            showDaysOff: true,
            fullscreen: false,
            draggingTaskId: null,
            dragOverTaskId: null,
            dragOverPosition: null,
            collapsedTaskIds: {},
        });

        onWillStart(async () => {
            await this.loadProjects();
            await this.loadData();
        });
    }

    async loadProjects() {
        this.state.projects = await this.orm.call("project.task", "project_gantt_get_projects", [], {});
    }

    async loadData() {
        this.state.loading = true;
        try {
            // Compatibilité: ne pas envoyer `sort` au serveur.
            // Si Odoo charge encore une ancienne version Python du module,
            // l'argument keyword `sort` provoque: unexpected keyword argument 'sort'.
            // Le tri est donc fait côté client.
            const tasks = await this.orm.call("project.task", "project_gantt_get_data", [], {
                project_id: this.state.projectId || false,
                start: this.state.start,
                end: this.getEndDate(),
            });
            this.state.tasks = this.sortTasks(tasks || []);
            this.cleanupCollapsedState();
        } finally {
            this.state.loading = false;
            setTimeout(() => this.syncLeftScroll(), 0);
        }
    }

    async onProjectChange(ev) {
        this.state.projectId = ev.target.value || "";
        await this.loadData();
    }

    async onScaleChange(ev) {
        this.state.scale = ev.target.value || "day";
        this.state.start = this.formatDate(this.alignStartForScale(this.parseDateSafe(this.state.start), this.state.scale));
        await this.loadData();
    }

    async onSortChange(ev) {
        this.state.sort = ev.target.value || "default";
        this.state.tasks = this.sortTasks(this.state.tasks || []);
    }

    async previousRange() {
        this.state.start = this.formatDate(this.addRangeStep(this.parseDateSafe(this.state.start), -1));
        await this.loadData();
    }

    async nextRange() {
        this.state.start = this.formatDate(this.addRangeStep(this.parseDateSafe(this.state.start), 1));
        await this.loadData();
    }

    async todayRange() {
        this.state.start = this.formatDate(this.alignStartForScale(this.addDays(this.todayLocal(), -2), this.state.scale));
        await this.loadData();
    }

    async refresh() {
        await this.loadProjects();
        await this.loadData();
    }

    getActionTitle() {
        if (!this.state.projectId) {
            return "Toutes les tâches";
        }
        const projectId = parseInt(this.state.projectId, 10);
        const project = (this.state.projects || []).find((row) => row.id === projectId);
        return project ? project.name : "Tâches du projet";
    }

    onSearchInput(ev) {
        this.state.search = ev.target.value || "";
        setTimeout(() => this.syncLeftScroll(), 0);
    }

    clearSearch() {
        this.state.search = "";
        setTimeout(() => this.syncLeftScroll(), 0);
    }

    async createTask() {
        const context = {
            default_gantt_start_date: this.state.start,
            default_gantt_start_datetime: this.state.start + " 08:00:00",
        };
        if (this.state.projectId) {
            context.default_project_id = parseInt(this.state.projectId, 10);
        }
        await this.action.doAction({
            type: "ir.actions.act_window",
            name: "Créer une tâche",
            res_model: "project.task",
            views: [[false, "form"]],
            target: "current",
            context,
        });
    }

    async openStandardView(viewType) {
        const domain = [];
        if (this.state.projectId) {
            domain.push(["project_id", "=", parseInt(this.state.projectId, 10)]);
        }
        await this.action.doAction({
            type: "ir.actions.act_window",
            name: this.getActionTitle(),
            res_model: "project.task",
            views: [[false, viewType]],
            target: "current",
            domain,
        });
    }

    exportVisibleTasks() {
        const rows = this.getVisibleTasks();
        if (!rows.length) {
            this.notification.add("Aucune tâche visible à exporter.", { type: "warning" });
            return;
        }
        const headers = ["Title", "Project", "Start", "End", "Duration", "Progress", "Stage", "Assigned To"];
        const csvRows = [headers.map((value) => this.csvEscape(value)).join(",")];
        for (const task of rows) {
            csvRows.push([
                task.name || "",
                task.project_name || "",
                task.start || "",
                task.end || "",
                task.duration_label || "",
                String(task.progress || 0),
                task.stage_name || "",
                task.user_names || "",
            ].map((value) => this.csvEscape(value)).join(","));
        }
        const csv = "\ufeff" + csvRows.join("\n");
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = "project_gantt_tasks_" + this.formatDate(this.todayLocal()) + ".csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }

    csvEscape(value) {
        const text = String(value == null ? "" : value);
        return '"' + text.replace(/"/g, '""') + '"';
    }

    async zoomToFit() {
        // Compatibilité serveur: ne pas appeler une nouvelle méthode Python ici.
        // Certaines installations Odoo gardent temporairement une ancienne copie
        // du modèle Python, ce qui provoque: project_gantt_get_bounds does not exist.
        // On réutilise donc project_gantt_get_data, déjà présent dans les versions
        // précédentes, avec une plage large, puis on calcule les bornes côté client.
        this.state.loading = true;
        try {
            const tasks = await this.orm.call("project.task", "project_gantt_get_data", [], {
                project_id: this.state.projectId || false,
                start: "2000-01-01",
                end: "2100-12-31",
            });
            const rows = tasks || [];
            if (!rows.length) {
                await this.todayRange();
                return;
            }

            let minStart = null;
            let maxEnd = null;
            for (const task of rows) {
                const taskStart = this.parseDateSafe(task.start);
                const taskEnd = this.parseDateSafe(task.end);
                if (!minStart || taskStart < minStart) {
                    minStart = taskStart;
                }
                if (!maxEnd || taskEnd > maxEnd) {
                    maxEnd = taskEnd;
                }
            }

            const days = Math.max(1, this.daysBetween(minStart, maxEnd));
            if (days <= 45) {
                this.state.scale = "day";
            } else if (days <= 160) {
                this.state.scale = "week";
            } else if (days <= 540) {
                this.state.scale = "month";
            } else {
                this.state.scale = "quarter";
            }
            this.state.start = this.formatDate(this.alignStartForScale(this.addDays(minStart, -2), this.state.scale));
            await this.loadData();
        } finally {
            this.state.loading = false;
            setTimeout(() => this.syncLeftScroll(), 0);
        }
    }


    sortTasks(tasks) {
        const rows = Array.from(tasks || []);
        const sort = this.state.sort || "default";
        if (sort === "name") {
            rows.sort((a, b) => (a.name || "").localeCompare(b.name || "") || (a.id || 0) - (b.id || 0));
        } else if (sort === "start") {
            rows.sort((a, b) => (a.start || "").localeCompare(b.start || "") || (a.name || "").localeCompare(b.name || ""));
        } else if (sort === "duration") {
            rows.sort((a, b) => (parseInt(b.duration_days || 0, 10) - parseInt(a.duration_days || 0, 10)) || (a.name || "").localeCompare(b.name || ""));
        } else if (sort === "project") {
            rows.sort((a, b) => (a.project_name || "").localeCompare(b.project_name || "") || (a.name || "").localeCompare(b.name || ""));
        }
        return rows;
    }

    toggleOption(optionName) {
        this.state[optionName] = !this.state[optionName];
    }

    toggleFullscreen() {
        this.state.fullscreen = !this.state.fullscreen;
    }

    syncLeftScroll() {
        const chart = this.chartScrollRef.el;
        const leftBody = this.leftBodyRef.el;
        if (!chart || !leftBody) {
            return;
        }
        leftBody.style.transform = "translate3d(0," + (-chart.scrollTop) + "px,0)";
    }

    onLeftWheel(ev) {
        const chart = this.chartScrollRef.el;
        if (!chart) {
            return;
        }
        if (ev.deltaY || ev.deltaX) {
            ev.preventDefault();
            if (ev.shiftKey) {
                chart.scrollLeft += ev.deltaY || ev.deltaX;
            } else {
                chart.scrollTop += ev.deltaY;
                chart.scrollLeft += ev.deltaX;
            }
            this.syncLeftScroll();
        }
    }

    getRootClass() {
        let cls = "o_pgantt_ce o_pgantt_like_enterprise";
        if (this.state.fullscreen) {
            cls += " is-fullscreen";
        }
        if (!this.state.showGrid) {
            cls += " is-grid-hidden";
        }
        if (!this.state.showDaysOff) {
            cls += " is-days-off-hidden";
        }
        return cls;
    }

    getScaleConfig() {
        if (this.state.scale === "week") {
            return { unit: "week", count: 16, cellWidth: 90, stepDays: 7 };
        }
        if (this.state.scale === "month") {
            return { unit: "month", count: 12, cellWidth: 120, stepMonths: 1 };
        }
        if (this.state.scale === "quarter") {
            return { unit: "quarter", count: 12, cellWidth: 130, stepMonths: 3 };
        }
        return { unit: "day", count: 21, cellWidth: 80, stepDays: 1 };
    }

    getCellWidth() {
        return this.getScaleConfig().cellWidth;
    }

    getEndDate() {
        const units = this.getTimeUnits();
        if (!units.length) {
            return this.state.start;
        }
        return this.formatDate(units[units.length - 1].end);
    }

    getTimeUnits() {
        const config = this.getScaleConfig();
        let current = this.alignStartForScale(this.parseDateSafe(this.state.start), this.state.scale);
        const units = [];
        for (let i = 0; i < config.count; i++) {
            let end;
            let label;
            let subtitle = "";
            let off = false;
            if (config.unit === "day") {
                end = this.addDays(current, 0);
                label = this.formatDayMonth(current);
                subtitle = this.getShortWeekday(current);
                off = this.isWeekend(current);
                units.push({ key: this.formatDate(current), start: current, end, label, subtitle, off });
                current = this.addDays(current, 1);
            } else if (config.unit === "week") {
                end = this.addDays(current, 6);
                label = this.formatDayMonth(current);
                subtitle = "→ " + this.formatDayMonth(end);
                units.push({ key: this.formatDate(current), start: current, end, label, subtitle, off: false });
                current = this.addDays(current, 7);
            } else if (config.unit === "month") {
                end = this.addDays(this.addMonths(current, 1), -1);
                label = this.getMonthLabel(current);
                subtitle = String(current.getFullYear());
                units.push({ key: this.formatDate(current), start: current, end, label, subtitle, off: false });
                current = this.addMonths(current, 1);
            } else {
                end = this.addDays(this.addMonths(current, 3), -1);
                label = this.getMonthLabel(current);
                subtitle = String(current.getFullYear());
                units.push({ key: this.formatDate(current), start: current, end, label, subtitle, off: false });
                current = this.addMonths(current, 3);
            }
        }
        return units;
    }

    getYearHeaders() {
        const units = this.getTimeUnits();
        const headers = [];
        const cellWidth = this.getCellWidth();
        for (const unit of units) {
            const year = String(unit.start.getFullYear());
            const last = headers.length ? headers[headers.length - 1] : null;
            if (last && last.label === year) {
                last.width += cellWidth;
            } else {
                headers.push({ key: year + "_" + unit.key, label: year, width: cellWidth });
            }
        }
        return headers;
    }

    gridWidth() {
        return this.getTimeUnits().length * this.getCellWidth();
    }

    gridHeight() {
        return Math.max(this.getVisibleTasks().length * this.rowHeight, this.rowHeight * 8);
    }

    getFilteredTaskRows() {
        const rows = Array.from(this.state.tasks || []);
        const query = (this.state.search || "").trim().toLowerCase();
        if (!query) {
            return rows;
        }
        return rows.filter((task) => {
            const haystack = [
                task.name,
                task.project_name,
                task.stage_name,
                task.user_names,
                task.start,
                task.end,
            ].join(" ").toLowerCase();
            return haystack.includes(query);
        });
    }

    getVisibleTasks() {
        const rows = this.getFilteredTaskRows();
        const taskById = new Map();
        for (const task of rows) {
            taskById.set(task.id, task);
        }
        return rows.filter((task) => !this.isHiddenByCollapsedAncestor(task, taskById));
    }

    isHiddenByCollapsedAncestor(task, taskById) {
        let parentId = task.parent_id || false;
        let guard = 0;
        while (parentId && guard < 20) {
            if (this.state.collapsedTaskIds && this.state.collapsedTaskIds[parentId]) {
                return true;
            }
            const parent = taskById.get(parentId);
            parentId = parent ? (parent.parent_id || false) : false;
            guard += 1;
        }
        return false;
    }

    isTaskCollapsed(task) {
        return !!(task && task.has_children && this.state.collapsedTaskIds && this.state.collapsedTaskIds[task.id]);
    }

    toggleTaskCollapsed(ev, task) {
        if (ev) {
            ev.preventDefault();
            ev.stopPropagation();
        }
        if (!task || !task.has_children) {
            return;
        }
        const next = Object.assign({}, this.state.collapsedTaskIds || {});
        if (next[task.id]) {
            delete next[task.id];
        } else {
            next[task.id] = true;
        }
        this.state.collapsedTaskIds = next;
        setTimeout(() => this.syncLeftScroll(), 0);
    }

    cleanupCollapsedState() {
        const validIds = new Set((this.state.tasks || []).filter((task) => task.has_children).map((task) => String(task.id)));
        const current = this.state.collapsedTaskIds || {};
        const next = {};
        for (const key of Object.keys(current)) {
            if (validIds.has(String(key))) {
                next[key] = true;
            }
        }
        this.state.collapsedTaskIds = next;
    }

    expandAllTasks() {
        this.state.collapsedTaskIds = {};
        setTimeout(() => this.syncLeftScroll(), 0);
    }

    collapseAllTasks() {
        const next = {};
        for (const task of this.state.tasks || []) {
            if (task.has_children) {
                next[task.id] = true;
            }
        }
        this.state.collapsedTaskIds = next;
        setTimeout(() => this.syncLeftScroll(), 0);
    }

    getLeftWidth() {
        let width = 240 + 150 + 170;
        if (this.state.showDuration) {
            width += 95;
        }
        return width;
    }

    getTitleStyle(task) {
        const pad = 12 + (parseInt(task.level || 0, 10) * 18);
        return "padding-left:" + pad + "px";
    }

    getTaskRowClass(task) {
        let cls = "o_pgantt_task_row";
        if (task.has_children) {
            cls += " is-parent";
        }
        if (this.isTaskCollapsed(task)) {
            cls += " is-collapsed";
        }
        if (this.state.showCriticalPath && task.is_critical) {
            cls += " is-critical";
        }
        if (this.state.draggingTaskId === task.id) {
            cls += " is-row-dragging";
        }
        if (this.state.dragOverTaskId === task.id && this.state.dragOverPosition) {
            cls += " is-drop-" + this.state.dragOverPosition;
        }
        return cls;
    }

    getBarClass(task) {
        let cls = "o_pgantt_bar";
        if (task.has_children) {
            cls += " is-parent";
        }
        if (task.is_milestone) {
            cls += " is-milestone";
        }
        if (task.unscheduled) {
            cls += " is-unscheduled";
        }
        if (this.state.showCriticalPath && task.is_critical) {
            cls += " is-critical";
        }
        return cls;
    }

    getBarStyle(task, index) {
        if (task.unscheduled) {
            return "display:none;";
        }
        const start = this.parseDateSafe(task.start);
        const end = this.parseDateSafe(task.end || task.start);
        const x1 = this.dateToX(start, false);
        if (task.is_milestone) {
            const left = Math.max(3, x1 - 7);
            const top = index * this.rowHeight + 11;
            return "left:" + left + "px;top:" + top + "px;width:14px;height:14px;";
        }
        const x2 = this.dateToX(this.addDays(end, 1), true);
        const left = Math.max(2, x1 + 3);
        const maxRight = this.gridWidth() - 3;
        const right = Math.min(maxRight, Math.max(left + 10, x2 - 3));
        const top = index * this.rowHeight + 7;
        const width = Math.max(right - left, 6);
        return "left:" + left + "px;top:" + top + "px;width:" + width + "px;";
    }

    getDeadlineStyle(task, index) {
        if (!task.deadline) {
            return "display:none;";
        }
        const deadline = this.parseDateSafe(task.deadline);
        const x = this.dateToX(deadline, false);
        const top = index * this.rowHeight + 4;
        return "left:" + x + "px;top:" + top + "px;height:" + (this.rowHeight - 8) + "px;";
    }

    getTodayStyle() {
        const x = this.dateToX(this.todayLocal(), false);
        if (x < 0 || x > this.gridWidth()) {
            return "display:none;";
        }
        return "left:" + x + "px;height:" + (this.gridHeight() + this.headerHeight) + "px;";
    }

    getProgressStyle(task) {
        const progress = Math.max(0, Math.min(parseInt(task.progress || 0, 10), 100));
        return "width:" + progress + "%;";
    }

    getResourceGroups() {
        const map = new Map();
        for (const task of this.getVisibleTasks()) {
            const names = task.user_names || "Non assigné";
            for (const rawName of names.split(",")) {
                const name = rawName.trim() || "Non assigné";
                if (!map.has(name)) {
                    map.set(name, { name, count: 0, tasks: [] });
                }
                const group = map.get(name);
                group.count += 1;
                if (group.tasks.length < 5) {
                    group.tasks.push(task.name);
                }
            }
        }
        return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name));
    }

    dateToX(date, endExclusive) {
        const units = this.getTimeUnits();
        const cellWidth = this.getCellWidth();
        if (!units.length) {
            return 0;
        }
        if (date < units[0].start) {
            return 0;
        }
        const lastEndExclusive = this.addDays(units[units.length - 1].end, 1);
        if (date >= lastEndExclusive) {
            return this.gridWidth();
        }
        let x = 0;
        for (const unit of units) {
            const unitEndExclusive = this.addDays(unit.end, 1);
            if (date >= unitEndExclusive) {
                x += cellWidth;
                continue;
            }
            const totalDays = Math.max(1, this.daysBetween(unit.start, unitEndExclusive));
            const elapsedDays = Math.max(0, this.daysBetween(unit.start, date));
            let ratio = elapsedDays / totalDays;
            if (endExclusive && elapsedDays >= totalDays) {
                ratio = 1;
            }
            return x + (ratio * cellWidth);
        }
        return x;
    }

    getAverageDaysPerCell() {
        const units = this.getTimeUnits();
        if (!units.length) {
            return 1;
        }
        let days = 0;
        for (const unit of units) {
            days += Math.max(1, this.daysBetween(unit.start, this.addDays(unit.end, 1)));
        }
        return days / units.length;
    }

    async openTask(taskId) {
        await this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "project.task",
            res_id: taskId,
            views: [[false, "form"]],
            target: "current",
        });
    }

    onTaskRowDragStart(ev, task) {
        ev.stopPropagation();
        if (this.state.sort !== "default") {
            ev.preventDefault();
            this.notification.add("Le glisser-déposer de l’ordre est disponible avec le tri Default.", { type: "warning" });
            return;
        }
        this.state.draggingTaskId = task.id;
        this.state.dragOverTaskId = null;
        this.state.dragOverPosition = null;
        if (ev.dataTransfer) {
            ev.dataTransfer.effectAllowed = "move";
            ev.dataTransfer.setData("text/plain", String(task.id));
        }
    }

    onTaskRowDragOver(ev, targetTask) {
        if (!this.state.draggingTaskId || this.state.draggingTaskId === targetTask.id) {
            return;
        }
        ev.preventDefault();
        ev.stopPropagation();
        if (ev.dataTransfer) {
            ev.dataTransfer.dropEffect = "move";
        }
        const rect = ev.currentTarget.getBoundingClientRect();
        const position = ev.clientY < rect.top + (rect.height / 2) ? "before" : "after";
        this.state.dragOverTaskId = targetTask.id;
        this.state.dragOverPosition = position;
    }

    onTaskRowDragLeave(ev, targetTask) {
        const related = ev.relatedTarget;
        if (related && ev.currentTarget.contains(related)) {
            return;
        }
        if (this.state.dragOverTaskId === targetTask.id) {
            this.state.dragOverTaskId = null;
            this.state.dragOverPosition = null;
        }
    }

    async onTaskRowDrop(ev, targetTask) {
        ev.preventDefault();
        ev.stopPropagation();

        const movedId = parseInt((ev.dataTransfer && ev.dataTransfer.getData("text/plain")) || this.state.draggingTaskId, 10);
        const position = this.state.dragOverPosition || "after";
        this.state.draggingTaskId = null;
        this.state.dragOverTaskId = null;
        this.state.dragOverPosition = null;

        if (!movedId || movedId === targetTask.id) {
            return;
        }

        const tasks = Array.from(this.state.tasks || []);
        const fromIndex = tasks.findIndex((row) => row.id === movedId);
        let toIndex = tasks.findIndex((row) => row.id === targetTask.id);
        if (fromIndex < 0 || toIndex < 0) {
            return;
        }

        const movedTask = tasks[fromIndex];
        if (movedTask.project_id !== targetTask.project_id) {
            this.notification.add("Déplace la tâche dans le même projet pour conserver une hiérarchie propre.", { type: "warning" });
            return;
        }

        tasks.splice(fromIndex, 1);
        if (position === "after") {
            toIndex += 1;
        }
        if (fromIndex < toIndex) {
            toIndex -= 1;
        }
        tasks.splice(Math.max(0, toIndex), 0, movedTask);
        this.state.tasks = tasks;

        try {
            const projectOrderedIds = tasks
                .filter((row) => row.project_id === movedTask.project_id)
                .map((row) => row.id);

            // Compatibilité maximale : on évite une méthode Python personnalisée
            // comme project_gantt_resequence. Si le serveur Odoo n'a pas encore
            // rechargé le dernier Python du module, cette méthode peut être absente.
            // Ici on utilise seulement la méthode standard `write` de project.task.
            for (let index = 0; index < projectOrderedIds.length; index++) {
                await this.orm.call("project.task", "write", [[projectOrderedIds[index]], { sequence: (index + 1) * 10 }], {});
            }
            this.notification.add("Ordre des tâches mis à jour.", { type: "success" });
        } catch (error) {
            this.notification.add("Impossible de réordonner les tâches.", { type: "danger" });
            await this.loadData();
            throw error;
        }
    }

    onTaskRowDragEnd() {
        this.state.draggingTaskId = null;
        this.state.dragOverTaskId = null;
        this.state.dragOverPosition = null;
    }

    onBarMouseDown(ev, task) {
        if (ev.button !== 0) {
            return;
        }
        ev.preventDefault();
        ev.stopPropagation();

        const bar = ev.currentTarget;
        const initialX = ev.clientX;
        let deltaDays = 0;
        bar.classList.add("is-dragging");

        const onMouseMove = (moveEv) => {
            const pixelsPerDay = this.getCellWidth() / this.getAverageDaysPerCell();
            deltaDays = Math.round((moveEv.clientX - initialX) / Math.max(1, pixelsPerDay));
            bar.style.transform = "translateX(" + ((moveEv.clientX - initialX)) + "px)";
        };

        const onMouseUp = async (upEv) => {
            document.removeEventListener("mousemove", onMouseMove);
            document.removeEventListener("mouseup", onMouseUp);
            bar.classList.remove("is-dragging");
            bar.style.transform = "";

            const pixelsPerDay = this.getCellWidth() / this.getAverageDaysPerCell();
            deltaDays = Math.round((upEv.clientX - initialX) / Math.max(1, pixelsPerDay));
            if (!deltaDays) {
                await this.openTask(task.id);
                return;
            }

            const newStart = this.addDays(this.parseDateSafe(task.start), deltaDays);
            const newEnd = task.is_milestone
                ? newStart
                : this.addDays(this.parseDateSafe(task.end || task.start), deltaDays);
            try {
                await this.orm.call("project.task", "project_gantt_update_dates", [
                    task.id,
                    this.formatDate(newStart),
                    this.formatDate(newEnd),
                ], {});
                await this.loadData();
                this.notification.add("Dates de la tâche mises à jour.", { type: "success" });
            } catch (error) {
                this.notification.add("Impossible de déplacer la tâche.", { type: "danger" });
                throw error;
            }
        };

        document.addEventListener("mousemove", onMouseMove);
        document.addEventListener("mouseup", onMouseUp);
    }

    alignStartForScale(date, scale) {
        if (scale === "week") {
            const copy = this.addDays(date, 0);
            const day = copy.getDay() || 7;
            return this.addDays(copy, 1 - day);
        }
        if (scale === "month") {
            return new Date(date.getFullYear(), date.getMonth(), 1);
        }
        if (scale === "quarter") {
            const qMonth = Math.floor(date.getMonth() / 3) * 3;
            return new Date(date.getFullYear(), qMonth, 1);
        }
        return date;
    }

    addRangeStep(date, direction) {
        const config = this.getScaleConfig();
        if (config.unit === "day") {
            return this.addDays(date, direction * config.count);
        }
        if (config.unit === "week") {
            return this.addDays(date, direction * config.count * 7);
        }
        if (config.unit === "month") {
            return this.addMonths(date, direction * config.count);
        }
        return this.addMonths(date, direction * config.count * 3);
    }

    parseDateSafe(value) {
        if (!value) {
            return this.todayLocal();
        }
        if (value instanceof Date) {
            return new Date(value.getFullYear(), value.getMonth(), value.getDate());
        }
        if (/^\d{4}-\d{2}-\d{2}/.test(value)) {
            const parts = value.slice(0, 10).split("-").map((part) => parseInt(part, 10));
            return new Date(parts[0], parts[1] - 1, parts[2]);
        }
        if (/^\d{2}\/\d{2}\/\d{4}$/.test(value)) {
            const parts = value.split("/").map((part) => parseInt(part, 10));
            return new Date(parts[2], parts[1] - 1, parts[0]);
        }
        const fallback = new Date(value);
        return new Date(fallback.getFullYear(), fallback.getMonth(), fallback.getDate());
    }

    todayLocal() {
        const now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), now.getDate());
    }

    addDays(date, days) {
        const copy = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        copy.setDate(copy.getDate() + days);
        return copy;
    }

    addMonths(date, months) {
        return new Date(date.getFullYear(), date.getMonth() + months, 1);
    }

    daysBetween(date1, date2) {
        const utc1 = Date.UTC(date1.getFullYear(), date1.getMonth(), date1.getDate());
        const utc2 = Date.UTC(date2.getFullYear(), date2.getMonth(), date2.getDate());
        return Math.floor((utc2 - utc1) / 86400000);
    }

    isWeekend(date) {
        const day = date.getDay();
        return day === 0 || day === 6;
    }

    formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return year + "-" + month + "-" + day;
    }

    formatDayMonth(date) {
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0");
        return day + "/" + month;
    }

    getShortWeekday(date) {
        const labels = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
        return labels[date.getDay()];
    }

    getMonthLabel(date) {
        const labels = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
        return labels[date.getMonth()];
    }
}

ProjectGanttCE.template = "project_gantt_ce.ProjectGanttCE";
registry.category("actions").add("project_gantt_ce.action", ProjectGanttCE);
